#client side
import socket

data = 16
format = "utf-8"
port =5050
device_name = socket.gethostname()
server_ip = socket.gethostbyname(device_name)
client_ip = socket.gethostbyname(device_name)
server_socket_addr = (server_ip, port)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(server_socket_addr)

def sending_message(msg):
    message = msg.encode(format) #hello
    msg_length = len(message)  #5
    msg_length_str = str(msg_length).encode(format)   #'5'
    msg_length_str += b" "*(data - len(msg_length_str)) #'5                      '
    client.send(msg_length_str)
    client.send(message)
    sent_from_server = client.recv(128).decode(format)
    print("Sent from server:", sent_from_server)

sending_message(f"Client's device name is {device_name} and the ip address is {client_ip}")
sending_message("disconnect")