#SERVER SIDE
import socket

format = "utf-8"
data = 16
port =5050
device_name = socket.gethostname()
server_ip = socket.gethostbyname(device_name)
server_socket_addr = (server_ip, port)

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)   # socket create kortesi
server.bind(server_socket_addr)  #binding

server.listen()
print("our server is listening..")
while True:
     server_socket, client_add    = server.accept() #blocking line
     print("Connected to", client_add) #printing client's socket address
     connected =True
     while connected:
        upcoming_message_length = server_socket.recv(data).decode(format)
        print("upcoming message length is", upcoming_message_length)
        if upcoming_message_length:
                message = server_socket.recv(int(upcoming_message_length)).decode(format)
                if message == 'disconnect':
                        print("Dissconnected with", client_add)
                        connected = False
                print(message)
                server_socket.send("Message Received".encode(format))
     server_socket.close()

