#include <stdio.h>
#include <ctype.h>

int main(){
   int upper_case=0;
   int lower_case=0;
   int digit=0;
   int special_char=0;
   char password[25];
   printf("Please, enter your password:");
   scanf("%s", password);
   
   for(int i=0; password[i] != '\0'; i++){
     if(isupper(password[i])){
      upper_case = 1;
     }else if(islower(password[i])){
      lower_case =1;
     }else if(isdigit(password[i])){
      digit=1;
     }else if(password[i]== '_'||password[i]== '$'||password[i]=='#'||password[i]=='@'){
     special_char=1;
   }
}
  int valid=1;
  if (!upper_case){
    printf("Uppercase character missing."); 
    valid = 0; 
  }
  if(!lower_case){
    printf("Lowercase character missing."); 
    valid = 0; 
  }
  if(!digit){
    printf("Digit missing."); 
    valid = 0; 
  }
  if(!special_char){
    printf("Special character missing."); 
    valid = 0; 
  }
  if(valid){
   printf("OK.\n");
  }
  return 0;
}















