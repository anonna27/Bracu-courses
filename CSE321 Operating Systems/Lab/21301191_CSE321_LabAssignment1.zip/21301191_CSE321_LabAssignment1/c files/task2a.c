#include <stdio.h>
#include <stdlib.h>
int main(){
  int a, b;
  printf("Please, enter the first number:");
  scanf("%d", &a);
  printf("Please, enter the second number:");
  scanf("%d", &b);  
  
  if(a>b){
   printf("The values are substracted: %d \n", a-b);
   }else if(a<b){
   printf("The values are added: %d \n", a+b);
   }else{
   printf("The values are multiplied: %d \n", a*b);
   }
   return 0;
}
