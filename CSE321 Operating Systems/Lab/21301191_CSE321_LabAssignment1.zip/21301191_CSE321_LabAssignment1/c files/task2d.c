#include <stdio.h>
#include <string.h>

int main(){
    char email_add[200];
    printf("Please, enter your email address:");
    scanf("%s", email_add); 
    char *old="@kaaj.com";
    char *new="@sheba.xyz";
    
    char *val = strchr(email_add,'@');
    if(val== NULL){
        printf("Invalid.\n");
        return 1; 
   }
    if (strcmp(val,old) == 0){
        printf("Email address is outdated.\n");
    }else if (strcmp(val,new) == 0){
        printf("Email address is okay.\n");
    }
    return 0;
}





