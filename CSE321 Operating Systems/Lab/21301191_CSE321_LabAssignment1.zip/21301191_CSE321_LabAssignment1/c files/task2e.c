#include <stdio.h> 
#include <string.h> 

int main(){ 
  char word[250];
  char *start;
  char *end; 
  int mismatched = 0; 
  printf("Please, enter a word: "); 
  scanf("%s", word); 
  start = word; 
  end = word+strlen(word)-1; 
  while(start<end){ 
    if (*start!=*end){
     mismatched = 1;
     break;
     } 
     start++; 
     end--; 
}
  if(mismatched==1){ 
    printf("Not Palindrome.\n"); 
  }else{ 
    printf("Palindrome.\n"); 
  } 
  return 0; 
  
}








