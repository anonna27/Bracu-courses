#include <stdio.h>
#include <string.h>

int main(){
   FILE *input, *output;
   char *splitted;
   char lines[500];
   char *word = " ";
   
   input = fopen("task2b_input.txt", "r");
   output = fopen("task2b_output.txt", "w");
   if(input ==NULL || output==NULL){
     if(input ==NULL){
       printf("Cannot open input file.\n");
     }else{
       printf("Cannot open output file.\n");
     }
     if( input != NULL){
        fclose(input);
     }
     return 1;  
   }
   while (fgets(lines, sizeof(lines), input) != NULL) {
        splitted = strtok(lines, word);
        while (splitted != NULL) {
            fprintf(output,"%s ",splitted);
            splitted = strtok(NULL,word);
        }
        fprintf(output,"\n");
    }
    fclose(input);  
    fclose(output);
    return 0;
}
