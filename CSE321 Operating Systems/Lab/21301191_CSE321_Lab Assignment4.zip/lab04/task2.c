#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <semaphore.h>
#include <stdio.h>
/*
This program provides a possible solution using mutex and semaphore.
use 5 Farmers and 5 ShopOwners to demonstrate the solution.
*/
#define MaxCrops 5 // Maximum crops a Farmer can produce or a Shpoowner can take
#define warehouseSize 5 // Size of the warehouse
sem_t empty;
sem_t full;
int in = 0;
int out = 0;
char crops[warehouseSize]={'R','W','P','S','M'}; //indicating room for different crops
char warehouse[warehouseSize]={'N','N','N','N','N'}; //initially all the room is empty
pthread_mutex_t mutex;

int stop=0;
void *Farmer(void *far)
{   int i;
    int f_id = *(int *)far; 
    while(!stop){
        sem_wait(&empty); 
        pthread_mutex_lock(&mutex);
        if(stop){
            pthread_mutex_unlock(&mutex);
            sem_post(&empty);
            break;
        }
        warehouse[in]=crops[in];
        printf("Farmer %d: Insert crops %c at %d\n",f_id,warehouse[in],in);
        in=(in+1)%warehouseSize; 
        pthread_mutex_unlock(&mutex); 
        sem_post(&full);
        pthread_mutex_lock(&mutex);
        printf("Farmer%d: ",f_id);
        for(i=0;i<warehouseSize;i++){
            printf("%c",warehouse[i]);
        }
        printf("\n");
        pthread_mutex_unlock(&mutex); 
        sleep(1); 
    }
    return 0;   
}

void *ShopOwner(void *sho)
{   int i;
    int s_id = *(int *)sho; 
    while(!stop){
        sem_wait(&full); 
        pthread_mutex_lock(&mutex);
        if(stop){
            pthread_mutex_unlock(&mutex);
            sem_post(&full);
            break;
        }
        char crop=warehouse[out];
        warehouse[out]='N'; 
        printf("Shop owner %d: Remove crops %c from %d\n",s_id,crop,out);
        out=(out+1)%warehouseSize;  
        pthread_mutex_unlock(&mutex); 
        sem_post(&empty); 
        pthread_mutex_lock(&mutex);
        printf("ShopOwner%d: ",s_id);
        for (i=0;i<warehouseSize; i++) {
            printf("%c",warehouse[i]);
        }
        printf("\n");
        pthread_mutex_unlock(&mutex);
        sleep(2); 
    }
    return 0;
}
int main()
{   int i;
    pthread_t Far[5],Sho[5];
    pthread_mutex_init(&mutex, NULL);
    sem_init(&empty,0,warehouseSize);//when the warehouse is full thread will wait
    sem_init(&full,0,0);//when the warehouse is empty thread will wait

    int a[5] = {1,2,3,4,5}; //Just used for numbering the Farmer and ShopOwner
    for(i=0;i<sizeof(a);i++){
        pthread_create(&Far[i],NULL,(void *)Farmer,&a[i]);
    }
    for(i=0;i<sizeof(a);i++){
        pthread_create(&Sho[i],NULL,(void *)ShopOwner,&a[i]);
    }
    sleep(0.25);
    pthread_mutex_lock(&mutex);
    stop= 1;
    pthread_mutex_unlock(&mutex);

    for(i=0;i<sizeof(a);i++){
        sem_post(&empty);
        sem_post(&full);
    }
    for(i=0;i<sizeof(a);i++){
        pthread_join(Far[i],NULL);
        pthread_join(Sho[i],NULL);
    }
    //  Closing or destroying mutex and semaphore
    pthread_mutex_destroy(&mutex);
    sem_destroy(&empty);
    sem_destroy(&full);
    return 0;   
}



