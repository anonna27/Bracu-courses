#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main(){
    int count,i,j,n,a;
    printf("Please enter the number of elements in the input: ");
    scanf("%d", &count);
    int arr[count];
    printf("Enter %d elements:\n", count);
    for (i=0; i<count; i++){
        scanf("%d", &arr[i]);
    }
    printf("The given input is sorted in descending order:\n");
    for (j=0;j<count; j++){
        for (n=0;n<count-j-1; n++){
            if (arr[n]<arr[n+1]){
                a=arr[n];
                arr[n]= arr[n+1];
                arr[n+1]= a;
            }
        }
    }
    for (int b =0; b<count; b++){
        printf("%d\n", arr[b]);
    }
    return 0;
}
