#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int count=1;
int main(){
   pid_t p, c1, c2, c3;
   int s;
   p = fork();
  
   if(p<0){
     perror("Failed");
     exit(1);
   } 
   else if (p>0){
     printf("%d.Parent process ID:%d\n",count,getpid());
     wait(&s);
   }else if (p==0){	
	count++;
	printf("%d.Child process ID:%d\n",count,getpid());
	c1= fork();
	count++;
	if (c1== 0){	
	   printf("%d.Grand Child process ID: %d\n",count,getpid());
	   exit(0);
	}
	c2 = fork();
	count++;
	if (c2== 0){
	   printf("%d.Grand Child process ID: %d\n",count,getpid());
	   exit(0);
	}
	c3 = fork();
	count++;
	if (c3== 0){
		printf("%d.Grand Child process ID:%d\n",count,getpid());
		exit(0);
	}
   }
   return 0;
}
	



