#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main(){
   pid_t pid1, pid2;
   int s;
   
   pid1= fork();
   if (pid1==-1){
     printf("Fork failed\n");
     exit(1);
   }
   if (pid1==0){
     pid2 = fork();
     if (pid2==-1){
        printf("Fork failed\n");
        exit(1);
      }
      if (pid2==0){
           printf("I am grandchild\n");
           exit(0);
      }else{
           wait(&s);
           printf("I am child\n");
           exit(0);
      }
    }else{
       wait(&s);
       printf("I am parent\n");   
    }
    return 0;
   
}






