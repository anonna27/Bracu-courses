#include <stdio.h>
#include <fcntl.h>
#include <unistd.h> 
#include <string.h> 

int main(){
    int fd;
    char buffer[1500];
    fd = open("test1.txt",O_RDWR|O_CREAT,0644); 
    if (fd == -1){
        perror("Failed to open the file");
        return 1;
    }
    printf("File 'test1.txt' opened\n");

    while(1){
        printf("Please enter a string or enter -1 to quit: ");
        fgets(buffer, sizeof(buffer),stdin);
        buffer[strcspn(buffer, "\n")] = '\0';
        if (strcmp(buffer, "-1") == 0) {
            break;
        }
        write(fd, buffer, strlen(buffer));
        write(fd,"\n",1); 
    }
    close(fd);
    printf("File closed.\n");
    return 0;
}

