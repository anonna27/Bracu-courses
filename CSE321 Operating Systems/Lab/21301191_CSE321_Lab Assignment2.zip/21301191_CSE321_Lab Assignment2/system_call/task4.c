#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid;
    pid = fork();
    if (pid == 0) {
        execlp("./sort", "./sort", NULL);
        exit(1);
    } else if (pid > 0) {
        wait(NULL);
        pid = fork();
        if (pid == 0) {
            execlp("./oddeven", "./oddeven", NULL);
            exit(1);
        } else if (pid > 0) {
            wait(NULL);
        } else {
            exit(1);
        }
    } 
    return 0;
}


