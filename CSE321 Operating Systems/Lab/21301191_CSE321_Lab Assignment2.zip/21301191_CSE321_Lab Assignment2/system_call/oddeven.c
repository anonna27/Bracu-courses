#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
int main(){
    int count;
    printf("Please enter the number of elements in the input: ");
    scanf("%d", &count);
    int arr[count];
    int odd[count],even[count];
    int o = 0, e = 0;
    printf("Enter %d elements:\n", count);
    for (int i = 0; i < count; i++){
        scanf("%d", &arr[i]);
        if (arr[i] % 2 == 0){
            even[e++] = arr[i];
        }else {
            odd[o++] = arr[i];
        }
    }
    printf("The odd numbers are:\n");
    for (int i = 0; i<o; i++){
        printf("%d\n",odd[i]);
    }
    printf("The even numbers are:\n");
    for (int i = 0; i<e; i++){
        printf("%d\n",even[i]);
    }
    return 0;
}
