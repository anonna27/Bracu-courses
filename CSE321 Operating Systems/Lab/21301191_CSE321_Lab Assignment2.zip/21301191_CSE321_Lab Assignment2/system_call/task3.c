#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main(){
   int parent =1;
   int c_counter=0;
   int g_counter=0;

   pid_t a,b,c;    
        	 
	a = fork();
	if (a==0){
  	   printf("child (A) created by parent\n");
  	   if (getpid()%2!=0){
    	      pid_t f = fork();
      	      if (f==0){
      	        printf("grandchild created\n");                  	
                exit(0);
    	      }       	 
    	      wait(NULL);            	 
    	      printf("Grandchild created sucessfully\n");//new child create korse so counter increasing
  	   }       	 
  	   exit(0);
	}else{
  	   c_counter++;
  	   wait(NULL);
  	   if (a%2!=0){
  	     g_counter++;
  	   }
	}
	
    
	b = fork();
	if (b==0){
  	   printf("child (B) created by parent\n");
  	   if (getpid()%2!=0){
    	      pid_t f = fork();
      	      if (f==0){
      	        printf("grandchild created\n");                  	
                exit(0);
    	      }       	 
    	      wait(NULL);            	 
    	      printf("Grandchild created sucessfully\n");//new child create korse so counter increasing
  	   }       	 
  	   exit(0);
	}else{
  	   c_counter++;
  	   wait(NULL);
  	   if (b%2!=0){
  	     g_counter++;
  	   }
	}
	 
	c = fork();
	if (c==0){
  	   printf("child (C) created by parent\n");
  	   if (getpid()%2!=0){
    	      pid_t f = fork();
      	      if (f==0){
      	        printf("grandchild created\n");                  	
                exit(0);
    	      }       	 
    	      wait(NULL);            	 
    	      printf("Grandchild created sucessfully\n");//new child create korse so counter increasing
  	   }       	 
  	   exit(0);
	}else{
  	   c_counter++;
  	   wait(NULL);
  	   if (c%2!=0){
  	     g_counter++;
  	   }
	}
 	printf("Total number of grandchild: %d\n",g_counter); 
 	printf("Total number of child: %d\n",c_counter);
	printf("Total number of process: %d\n", parent+g_counter+c_counter);
	return 0;

}



