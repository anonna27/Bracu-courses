#include <stdio.h>
#include <string.h>

struct Restaurant_order
{   int quantity;
    float unit_price;
};

int main(){
     int num_of_people;
     float total_bill;
     float per_person_bill;
     
     struct Restaurant_order paratha;
     printf("Quantity Of Paratha: ");
     scanf("%d", &paratha.quantity);
     printf("Unit Price: ");
     scanf("%f", &paratha.unit_price);
     
     struct Restaurant_order Vegetable;
     printf("Quantity Of Vegetable: ");
     scanf("%d", &Vegetable.quantity);
     printf("Unit Price: ");
     scanf("%f", &Vegetable.unit_price);
     
     struct Restaurant_order MineraL_Water;
     printf("Quantity Of Mineral Water: ");
     scanf("%d", &MineraL_Water.quantity);
     printf("Unit Price: ");
     scanf("%f", &MineraL_Water.unit_price);

     printf("Number of People: ");
     scanf("%d", &num_of_people);
     total_bill = (paratha.quantity*paratha.unit_price)+        (Vegetable.quantity*Vegetable.unit_price) + (MineraL_Water.quantity*MineraL_Water.unit_price);
     per_person_bill = total_bill/num_of_people;
     printf("Individual people will pay:%.2f tk \n", per_person_bill);
     return 0;
     


}
