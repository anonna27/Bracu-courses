#include <stdio.h>
#include <string.h>

int main(){
   int input1;
   int input2;
   printf("Please give the range, from:");
   scanf("%d", &input1);
   printf("to:");
   scanf("%d", &input2);
   
   if(input1>input2){
    printf("Invalid. \n");
    return 1;
   }
   int i, j;
   for(i=input1; i<=input2; i++){
      int sum=0;
      for(j=1; j<=i/2; j++){
        if(i % j ==0){
          sum = sum + j;
        }
      }
      if (sum == i){
        printf("%d\n", i);
      }
    } 
    return 0; 
}
