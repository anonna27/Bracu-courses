#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>

void *funcThread(void *arg) {
    static int result;
    char name[50];
    printf("Please enter your name:");
    scanf("%s", name);
    result= add_ascii(name);
    return &result;
}

int add_ascii(char *name){
    int sum = 0;
    int i = 0;
    while (name[i] !='\0') {
        sum = sum + name[i];
        i++;
    }
    return sum;
}

int main() {
    pthread_t threads[3];
    int values[3];

    for (int i = 0; i<3; i++) {
        void *a;
        pthread_create(&threads[i], NULL,funcThread, NULL);
        pthread_join(threads[i], &a);
        values[i] = *(int *)a;
    }
    if (values[0] == values[1] && values[1] ==values[2]) {
        printf("Youreka\n");
    }else if(values[0] == values[1] ||values[0] ==values[2] ||values[1] ==values[2]){
        printf("Miracle\n");
    } else {
        printf("Hasta la vista\n");
    }
    return 0;
}


