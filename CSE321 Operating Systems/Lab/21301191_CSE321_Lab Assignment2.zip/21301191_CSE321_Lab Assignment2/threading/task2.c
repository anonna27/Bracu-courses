#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>

int thread_no=1;
int value=1;
void *funcThread(void *arg){
	for (int j=0; j<5; j++){
		printf("Thread %d prints %d\n",thread_no,value);
		sleep(1);
		value++;
	}
	thread_no++;
}

int main(){
	pthread_t thread_arr[5];
	int i;
	for (i=0; i<5; i++){
		pthread_create(&thread_arr[i],NULL,funcThread,NULL);
		pthread_join(thread_arr[i],NULL);
	}
	return 0;
}
