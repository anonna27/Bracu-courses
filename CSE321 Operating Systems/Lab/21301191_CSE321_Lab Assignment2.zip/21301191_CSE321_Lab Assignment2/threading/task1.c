#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

void *funcThread(void *arg);
int main(){
    pthread_t threads[5]; 
    int i;
    for (i = 0;i<5;i++){
        int num = i + 1;
        pthread_create(&threads[i], NULL,funcThread,(void *)&num);
        pthread_join(threads[i], NULL);
    }
    return 0;
}
void *funcThread(void *arg){
    int t_num = *(int*)arg;
    printf("thread-%d running\n", t_num);
    sleep(2);
    printf("thread-%d closed\n", t_num);
}

