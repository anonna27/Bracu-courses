#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h> 

struct msg{
  long int type;                 
  char txt[6];
};

int main(){
    int msg_id;
    struct msg data;
    pid_t pid1, pid2, pid3;
    char workspace[10];
    msg_id = msgget((key_t)101,0666|IPC_CREAT);
    if (msg_id <0){
        printf("Error\n");
        exit(1);
    }
    printf("Please enter the workspace name:\n");
    scanf("%6s", workspace);
    if (strcmp(workspace,"cse321")!= 0) {
        printf("Invalid workspace name\n");
        msgctl(msg_id,IPC_RMID,0); 
        exit(0);
    }
    
    data.type= 2;
    strcpy(data.txt,workspace);
    if(msgsnd(msg_id, &data,sizeof(data.txt),0)==-1){
        perror("Error");
        exit(1);
    }
    printf("Workspace name sent to otp generator from log in:%s\n",data.txt);
    
    pid1=fork();
    if(pid1==-1){
        perror("Error");
        exit(1);
    }
    if(pid1==0){ 
      if(msgrcv(msg_id, &data, sizeof(data.txt),2,0) ==-1){
            perror("Error");
            exit(1);
      }
      printf("OTP generator received workspace name from log in: %s\n",data.txt);
      pid2= getpid(); 
      snprintf(data.txt, sizeof(data.txt),"%d",pid2);
      
      data.type = 4; 
      if(msgsnd(msg_id, &data,sizeof(data.txt),0)==-1){
	perror("Error");
	exit(1);
      }
      printf("OTP sent to log in from OTP generator:%s\n",data.txt);
      
      data.type = 5; 
      if(msgsnd(msg_id, &data,sizeof(data.txt),0)==-1){
	perror("Error");
	exit(1);
      }
      printf("OTP sent to mail from OTP generator:%s\n",data.txt);
      
      pid3= fork();
      if(pid3<0) {
	perror("Error");
	exit(1);
      }else if(pid3== 0){ 
            if(msgrcv(msg_id,&data,sizeof(data.txt),5,0) ==-1){
                perror("Error");
                exit(1);
            }
            printf("Mail received OTP from OTP generator:%s\n",data.txt);
            
            data.type = 10;
            if(msgsnd(msg_id,&data,sizeof(data.txt),0) ==-1){
                perror("Error");
                exit(1);
            }
            printf("OTP sent to log in from mail: %s\n",data.txt);
            exit(0);
      }else{
        wait(NULL);
        exit(0);
      }
    }else{
    wait(NULL);
    char generator_otp[10];
    char mail_otp[10];
    if (msgrcv(msg_id, &data, sizeof(data.txt),4,0) ==-1){
	  perror("Error");
    }
    strcpy(generator_otp, data.txt);
    printf("Log in received OTP from OTP generator:%s\n",generator_otp);
    
    if (msgrcv(msg_id, &data, sizeof(data.txt),10,0) ==-1){
       perror("Error");
    }  
    strcpy(mail_otp,data.txt);
    printf("Log in received OTP from mail: %s\n",mail_otp);
    
    if(strcmp(generator_otp,mail_otp) == 0){
        printf("OTP Verified\n");
    }else{
        printf("OTP Incorrect\n");
    }
    msgctl(msg_id,IPC_RMID,NULL);
    return 0;
    }

}




