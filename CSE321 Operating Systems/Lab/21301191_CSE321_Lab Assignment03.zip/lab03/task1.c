#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h> 

struct shared{
    char sel[100];
    int b;
};

int main(){ 
    pid_t pid;
    void *s_m;  
    int fd[2]; 
    char buff[100]; 
    int sm_id; 
    int add_money, withdraw_money;
    const char *sentence = "Thank you for using";

    // Create shared memory
    sm_id = shmget((key_t)101, sizeof(struct shared), IPC_CREAT|0666);
    s_m = shmat(sm_id, NULL, 0); 
    struct shared *shm = (struct shared *)s_m;
    shm->b = 1000;
    int p=pipe(fd);
    if(p==-1){
         perror("pipe");}
    printf("Provide Your Input From Given Options:\n");
    printf("1. Type a to Add Money\n");
    printf("2. Type w to Withdraw Money\n");
    printf("3. Type c to Check Balance\n");
    scanf("%s", shm->sel);
    printf("Your selection: %s\n\n", shm->sel);
    pid = fork();
    if(pid < 0){
        perror("fork failed");
        exit(1);
    }
    if(pid == 0){
        close(fd[0]); 
        if (strcmp(shm->sel,"a") == 0){ 
            printf("Enter amount to be added:\n");
            scanf("%d", &add_money);
            if (add_money>0){
                shm->b+=add_money;
                printf("Balance added successfully\n");
                printf("Updated balance after addition: %d\n", shm->b);
            }else{
                printf("Adding failed, Invalid amount\n");
            }
        }else if (strcmp(shm->sel, "w")==0){ 
            printf("Enter amount to be withdrawn:\n");
            scanf("%d", &withdraw_money);
            if (withdraw_money> 0 && withdraw_money<= shm->b){
                shm->b -=withdraw_money;
                printf("Balance withdrawn successfully\n");
                printf("Updated balance after withdrawal: %d\n",shm->b);
            }else {
                printf("Withdrawal failed, Invalid amount\n");
            }
        }else if (strcmp(shm->sel, "c") ==0){
            printf("Your current balance is: %d\n",shm->b);
        }else {
            printf("Invalid selection\n");
        }
        write(fd[1],sentence, strlen(sentence)+1);
        close(fd[1]); 
        exit(0);
    }else{ 
        close(fd[1]); 
        wait(NULL);
        read(fd[0], buff, sizeof(buff));
        printf("%s\n",buff);
        shmdt(shm);
        shmctl(sm_id, IPC_RMID, NULL);
        close(fd[0]);
        exit(0);
    }
    
    
    return 0;
}

